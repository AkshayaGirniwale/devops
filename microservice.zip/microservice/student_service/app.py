# student_service_mysql/app.py
from flask import Flask, request, jsonify
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
import os
import time

app = Flask(__name__)

# Database connection details from environment variable
# Using mysql+pymysql for MySQL connector
DATABASE_URL = os.getenv('DATABASE_URL', 'mysql+pymysql://student_user:student_password@localhost:3306/student_db')

# SQLAlchemy setup
Base = declarative_base()

class Student(Base):
    """SQLAlchemy model for a Student."""
    __tablename__ = 'students'
    id = Column(Integer, primary_key=True, autoincrement=True) # autoincrement for MySQL
    name = Column(String(255), nullable=False)
    grade = Column(Integer, nullable=False)

    def to_dict(self):
        return {"id": self.id, "name": self.name, "grade": self.grade}

def init_db():
    """Initializes the database connection and creates tables."""
    global engine, Session
    max_retries = 15 # Increased retries for MySQL
    retry_delay_seconds = 5

    for i in range(max_retries):
        try:
            print(f"Attempting to connect to MySQL for students ({i+1}/{max_retries})...")
            engine = create_engine(DATABASE_URL)
            # Try to connect to verify
            connection = engine.connect()
            connection.close()
            Base.metadata.create_all(engine) # Create tables if they don't exist
            Session = sessionmaker(bind=engine)
            print("Student MySQL database connection successful and tables created.")
            return
        except Exception as e:
            print(f"Student MySQL database connection failed: {e}")
            if i < max_retries - 1:
                time.sleep(retry_delay_seconds)
            else:
                print("Max retries reached. Could not connect to the Student MySQL database.")
                raise

@app.before_first_request
def setup_db():
    """Ensures database is initialized before the first request."""
    init_db()

# Different endpoint for GET students
@app.route('/students', methods=['GET'])
def get_students():
    """Retrieves all students from the database."""
    session = Session()
    try:
        students = session.query(Student).all()
        return jsonify([student.to_dict() for student in students])
    except Exception as e:
        print(f"Error fetching students: {e}")
        return jsonify({"error": "Failed to fetch students"}), 500
    finally:
        session.close()

# Different endpoint for POST students
@app.route('/students', methods=['POST'])
def create_student():
    """Creates a new student in the database."""
    data = request.json
    if not data or 'name' not in data or 'grade' not in data:
        return jsonify({"error": "Student name and grade are required"}), 400

    try:
        grade = int(data['grade']) # Ensure grade is an integer
        new_student = Student(name=data['name'], grade=grade)
        session = Session()
        try:
            session.add(new_student)
            session.commit()
            return jsonify(new_student.to_dict()), 201
        except Exception as e:
            session.rollback()
            print(f"Error creating student: {e}")
            return jsonify({"error": "Failed to create student"}), 500
        finally:
            session.close()
    except ValueError:
        return jsonify({"error": "Grade must be an integer"}), 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5002, debug=True)
