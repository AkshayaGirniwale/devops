# flask_homepage/app.py
from flask import Flask, render_template, request, jsonify
import requests
import os

app = Flask(__name__)

# Environment variables for microservice URLs
# These URLs now point to the MySQL-backed services
TEACHER_SERVICE_URL = os.getenv('TEACHER_SERVICE_URL', 'http://localhost:5001')
STUDENT_SERVICE_URL = os.getenv('STUDENT_SERVICE_URL', 'http://localhost:5002')

@app.route('/')
def index():
    """Renders the main homepage."""
    return render_template('index.html')

@app.route('/teachers', methods=['GET'])
def get_teachers():
    """Fetches teachers from the Teacher Service."""
    try:
        # Calls the teacher service's /teachers endpoint
        response = requests.get(f"{TEACHER_SERVICE_URL}/teachers")
        response.raise_for_status() # Raise an exception for HTTP errors
        teachers = response.json()
        return jsonify(teachers)
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Could not connect to Teacher Service: {e}"}), 500

@app.route('/teachers', methods=['POST'])
def create_teacher():
    """Creates a new teacher via the Teacher Service."""
    data = request.json
    if not data or 'name' not in data or 'subject' not in data:
        return jsonify({"error": "Missing 'name' or 'subject' for teacher"}), 400
    try:
        # Calls the teacher service's /teachers endpoint
        response = requests.post(f"{TEACHER_SERVICE_URL}/teachers", json=data)
        response.raise_for_status()
        return jsonify(response.json()), 201
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Could not connect to Teacher Service: {e}"}), 500

@app.route('/students', methods=['GET'])
def get_students():
    """Fetches students from the Student Service."""
    try:
        # Calls the student service's /students endpoint
        response = requests.get(f"{STUDENT_SERVICE_URL}/students")
        response.raise_for_status()
        students = response.json()
        return jsonify(students)
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Could not connect to Student Service: {e}"}), 500

@app.route('/students', methods=['POST'])
def create_student():
    """Creates a new student via the Student Service."""
    data = request.json
    if not data or 'name' not in data or 'grade' not in data:
        return jsonify({"error": "Missing 'name' or 'grade' for student"}), 400
    try:
        # Calls the student service's /students endpoint
        response = requests.post(f"{STUDENT_SERVICE_URL}/students", json=data)
        response.raise_for_status()
        return jsonify(response.json()), 201
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Could not connect to Student Service: {e}"}), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
