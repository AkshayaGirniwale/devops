from flask import Flask, request, jsonify
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
import os
import time

app = Flask(__name__)

# Database connection details from environment variable
# Using mysql+pymysql for MySQL connector
DATABASE_URL = os.getenv('DATABASE_URL', 'mysql+pymysql://teacher_user:teacher_password@localhost:3306/teacher_db')

# SQLAlchemy setup
Base = declarative_base()

class Teacher(Base):
    """SQLAlchemy model for a Teacher."""
    __tablename__ = 'teachers'
    id = Column(Integer, primary_key=True, autoincrement=True) # autoincrement for MySQL
    name = Column(String(255), nullable=False)
    subject = Column(String(255), nullable=False)

    def to_dict(self):
        return {"id": self.id, "name": self.name, "subject": self.subject}

def init_db():
    """Initializes the database connection and creates tables."""
    global engine, Session
    max_retries = 15 # Increased retries for MySQL as it can take longer to be ready
    retry_delay_seconds = 5

    for i in range(max_retries):
        try:
            print(f"Attempting to connect to MySQL for teachers ({i+1}/{max_retries})...")
            engine = create_engine(DATABASE_URL)
            # Try to connect to verify
            connection = engine.connect()
            connection.close()
            Base.metadata.create_all(engine) # Create tables if they don't exist
            Session = sessionmaker(bind=engine)
            print("Teacher MySQL database connection successful and tables created.")
            return
        except Exception as e:
            print(f"Teacher MySQL database connection failed: {e}")
            if i < max_retries - 1:
                time.sleep(retry_delay_seconds)
            else:
                print("Max retries reached. Could not connect to the Teacher MySQL database.")
                raise

@app.before_first_request
def setup_db():
    """Ensures database is initialized before the first request."""
    init_db()

# Different endpoint for GET teachers
@app.route('/teachers', methods=['GET'])
def get_teachers():
    """Retrieves all teachers from the database."""
    session = Session()
    try:
        teachers = session.query(Teacher).all()
        return jsonify([teacher.to_dict() for teacher in teachers])
    except Exception as e:
        print(f"Error fetching teachers: {e}")
        return jsonify({"error": "Failed to fetch teachers"}), 500
    finally:
        session.close()

# Different endpoint for POST teachers
@app.route('/teachers', methods=['POST'])
def create_teacher():
    """Creates a new teacher in the database."""
    data = request.json
    if not data or 'name' not in data or 'subject' not in data:
        return jsonify({"error": "Teacher name and subject are required"}), 400

    new_teacher = Teacher(name=data['name'], subject=data['subject'])
    session = Session()
    try:
        session.add(new_teacher)
        session.commit()
        return jsonify(new_teacher.to_dict()), 201
    except Exception as e:
        session.rollback()
        print(f"Error creating teacher: {e}")
        return jsonify({"error": "Failed to create teacher"}), 500
    finally:
        session.close()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001, debug=True)